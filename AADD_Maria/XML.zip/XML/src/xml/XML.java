package xml;

import java.io.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import org.w3c.dom.*;

public class XML {

    public static void main(String[] args) {
    }
    
}

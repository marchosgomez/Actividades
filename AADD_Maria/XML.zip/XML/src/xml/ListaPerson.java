package xml;

import java.util.ArrayList;
import java.util.List;

public class ListaPerson {
    
    private List <Person> lista = new ArrayList <> ();
    
    public ListaPerson () { super (); }
    
    public void add (Person persona) {
        lista.add (persona);
    }
    
    public List <Person> getListaPerson () {
        return lista;
    }
}

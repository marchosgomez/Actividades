package xml;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import javax.swing.JOptionPane;

public class AltasObj {
        public static void altas(File fichero) throws IOException {
        
        ObjectOutputStream oos;
        if (fichero.exists()) {
            oos = new ObjectOutputStream(new FileOutputStream(fichero, true));
            
            String firstName = JOptionPane.showInputDialog ("Introduce el nombre:");
            String lastName = JOptionPane.showInputDialog ("Introduce el apellido:");
            int codePhone = Integer.parseInt (JOptionPane.showInputDialog ("Introduce el código del teléfono:"));
            String numberPhone = JOptionPane.showInputDialog ("Introduce el número del teléfono:");
            int codeFax = Integer.parseInt (JOptionPane.showInputDialog ("Introduce el código del fax:"));
            String numberFax = JOptionPane.showInputDialog ("Introduce el número del fax:");
            
            Person per = new Person ();
            PhoneNumber phone = new PhoneNumber (codePhone, numberPhone);
            PhoneNumber fax = new PhoneNumber (codeFax, numberFax);
            per.setFirstname (firstName);
            per.setLastname (lastName);
            per.setPhone (phone);
            per.setFax (fax);
            
            oos.writeObject (per);
            oos.close();
            
        } else {
            System.out.println("Fichero inexistente.");

        }
    }
}

package xml;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import com.thoughtworks.xstream.XStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class CrearPerson {
    public static void main (String [] args) throws IOException, ClassNotFoundException {
        File fichero = new File (".\\Person.dat");
        
        // Crear un fichero secuencial donde introducir una persona.
        AltasObj.altas (fichero);
        
        // Crear
        ListaPerson lista = new ListaPerson ();
        
        FileInputStream lectura = new FileInputStream (fichero);
        try (ObjectInputStream datos = new ObjectInputStream (lectura)) {
            while (true) {
                Person persona = (Person) datos.readObject ();
                lista.add (persona);
            }
        } catch (IOException ioe) {
            ioe.getMessage ();
        }

        try {
            FileOutputStream fileXML = new FileOutputStream ("PersonXML.xml");
            XStream xstream = new XStream ();
            xstream.alias ("ListadoPersonas", ListaPerson.class);
            xstream.alias ("DatosPersona", Person.class);
            xstream.addImplicitCollection (ListaPerson.class, "lista");
            
            xstream.toXML (lista, fileXML);
        } catch (FileNotFoundException e) {
            e.getMessage ();
        }
    }
    
}

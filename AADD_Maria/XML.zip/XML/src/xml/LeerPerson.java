/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 *
 * @author a13marcosga
 */
public class LeerPerson {
            // Lectura del fichero xml con dom.
        
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance ();
        
        try {
            DocumentBuilder db = dbf.newDocumentBuilder ();
            
            // Crear nuevo documento en memoria con el nodo raíz de nombre Personas.
            DOMImplementation implementacion = db.getDOMImplementation ();
            Document documento = implementacion.createDocument (null, "Person", null);
            // Asignar la versión xml al documento.
            documento.setXmlVersion ("1.0");
            
            // Crear el nodo person.
            Element raiz = documento.createElement ("person");
            // Pegarlo a la raiz del documento.
            documento.getDocumentElement ().appendChild (raiz);
            // Añadir los hijos al nodo raiz.
            CrearElemento ("firstname", firstname.trim (), raiz, documento);
            CrearElemento ("lastname", lastname.trim (), raiz, documento);
            CrearElemento ("phone", )
            
        } catch (ParserConfigurationException pce) {
            pce.getMessage ();
        }


}
